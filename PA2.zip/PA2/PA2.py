import pandas as pd

movies = pd.read_csv('movies.csv')
links = pd.read_csv('links.csv')
rating = pd.read_csv('ratings.csv')
tags = pd.read_csv('tags.csv')

df = pd.merge(rating,movies, on='movieId')

movie_matrix = df.pivot_table(index= 'userId', columns = 'title', values='rating')
corr_matrix = movie_matrix.corr(method = 'pearson', min_periods = 50)
with open('D:/PA2.txt', 'w') as f:
    
    for i in range(1,len(movie_matrix)-1): 
        userratings = movie_matrix.iloc[i].dropna()
       
        recommend = pd.Series()
    
        for j in range(0, len(userratings)):
            similar = corr_matrix[userratings.index[j]].dropna()
            similar = similar.map(lambda x:x * userratings[j])
            recommend = recommend.append(similar)
        recommend.sort_values(inplace = True, ascending = False)
        x= pd.DataFrame(recommend)
        recommend_filter = x[~x.index.isin(userratings.index)] 
        print(recommend_filter.head(5))                 
        f.write ("\n User Id "+ str(i)+'\t')
        f.write(' '.join((recommend_filter.head(5)).to_string(header=False,
                        index=True,
                        index_names=False).split('\n')))