import csv
import pickle
import pandas as pd
from apyori import apriori


index = 0
temp = 0

with open('D:/browsing-data.txt','r') as csvfile:
    datareader = csv.reader(csvfile, delimiter = ' ')
    for row in datareader:
        new_str = ''
       # print('Length:', len(row))

        if index == 0:
            temp = len(row)
        elif len(row)>temp:
            temp = len(row)
        index = index+1

        for x in range(len(row)):
            if(row[x] != ''):
                new_str += row[x]
                new_str += ','
        print(new_str)

        print('#####################')
        print('#####################')

print('Maximum Length: ', temp)

maxLength = temp

index = 0
temp = 0

new_file = ''

with open('D:/browsing-data.txt','r') as csvfile:
    datareader = csv.reader(csvfile, delimiter = ' ')
    for row in datareader:
        new_str = ''
        #print('Length:', len(row))
        index += 1
        #print('index: ',index)

        for x in range(len(row)):
            if(row[x] != ''):
                new_str += row[x]
                new_str += ','

        #print(new_str)
        if len(row)<maxLength:
            diff= maxLength - len(row)
            for x in range(len(row),maxLength):
                new_str +=','
        
        #print (new_str)

        new_file= new_file + '\n' + new_str + '\n'

        #print('##############')
        #print('##############')

print(maxLength)
print(new_file)

with open('D:/browsing-data.txt','r') as csvfile:
    datareadcsv = csv.reader(csvfile, delimiter =',')
    for row in datareadcsv:
        # print(row)
        print(len(row))

input_data = pd.read_csv('D:/browsing-data.txt',header=None)
#input_data =input_data.set_index([0]).T
#input_data.to

input_data.head()

input_data.dropna()
input_data.head()
input_data.info() 

records=[] 
rows = input_data.shape[0]
cols = input_data.shape[1]

for i in range (0,50):
    records.append([str(input_data.values[i,j]) for j in range(0,38)])

print("The iL is prepared")

pa1rules = apriori(records, min_support = 0.0321, min_confidence = 0.4, min_lift = 3, min_length = 2 )
print(" The algorithm specified is executed")
pa1results = list(pa1rules)


print (len(pa1results))

with open('D:/browsing-data.txt' , 'w') as f:
    for item in pa1results:
        pair = item[0]
        items = [x for x in pair]
        f.write("The Rule: "+ items[0] + " -> " + items[1])

        f.write ("TheSupport: "+ str(item[1]))

        f.write("Confidence: " + str(item[2][0][2]))
        f.write("Lift: "+ str(item[2][0][3]))  v
        f.write("======================================")
